<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>View Document</title>
	<?php include 'header.php';?>
</head>
<body>
	<div class="col-sm-2">
		<?php include 'sidenav.php';?>
	</div>
	<div class="col-sm-10 text-left">
		<!-- content -->
	</div>


</body>
</html>
